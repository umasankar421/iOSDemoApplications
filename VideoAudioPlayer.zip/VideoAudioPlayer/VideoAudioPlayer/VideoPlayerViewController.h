//
//  VideoPlayerViewController.h
//  VideoAudioPlayer
//
//  Created by Vikas Mishra on 12/23/16.
//  Copyright © 2016 dev. All rights reserved.
//

#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>
@interface VideoPlayerViewController : AVPlayerViewController

@end
