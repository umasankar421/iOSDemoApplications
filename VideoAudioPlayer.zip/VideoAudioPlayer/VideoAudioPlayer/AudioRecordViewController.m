//
//  AudioRecordViewController.m
//  VideoAudioPlayer
//
//  Created by Amresh Singh on 1/6/17.
//  Copyright © 2017 dev. All rights reserved.
//

#import "AudioRecordViewController.h"

@interface AudioRecordViewController ()

@end

@implementation AudioRecordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setUpAudioRecorder];
    
    [self setUpAudioPLayer];
    // Do any additional setup after loading the view.
}
-(void)setUpAudioRecorder{
    NSArray *pathComponents = [NSArray arrayWithObjects:
                               [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject],
                               @"MyAudioMemo.m4a",
                               nil];
    NSURL *outputFileURL = [NSURL fileURLWithPathComponents:pathComponents];
    
    // Setup audio session
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [session setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    
    // Define the recorder setting
    NSMutableDictionary *recordSetting = [[NSMutableDictionary alloc] init];
    
    [recordSetting setValue:[NSNumber numberWithInt:kAudioFormatMPEG4AAC] forKey:AVFormatIDKey];
    [recordSetting setValue:[NSNumber numberWithFloat:44100.0] forKey:AVSampleRateKey];
    [recordSetting setValue:[NSNumber numberWithInt: 2] forKey:AVNumberOfChannelsKey];
    
    // Initiate and prepare the recorder
    audioRecorder = [[AVAudioRecorder alloc] initWithURL:outputFileURL settings:recordSetting error:NULL];
    audioRecorder.delegate = self;
    audioRecorder.meteringEnabled = YES;
    [audioRecorder prepareToRecord];
    
   
}

-(void)setUpAudioPLayer{
    NSError *error;
    NSURL *audioURL = [NSURL URLWithString:[[NSBundle mainBundle] pathForResource:@"song" ofType:@"mp3"]];
    
    NSURL *url = audioRecorder.url;
    //audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:[NSURL URLWithString:[[NSBundle mainBundle] pathForResource:@"song" ofType:@"mp3"]] error:&error];
    
    audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
    
    if (error) {
        NSLog(@"Error : %@", [error localizedDescription]);
    } else {
        [audioPlayer prepareToPlay];
        NSLog(@"URL : %@",audioURL.absoluteString);
    }
}

#pragma AVAudioRecorderDelegate methods

-(void)audioRecorderDidFinishRecording:(AVAudioRecorder *)recorder successfully:(BOOL)flag{
    
    NSLog(@"Recorded Successfully : %@",recorder.url.absoluteString);
}


-(void)captureOutput:(AVCaptureOutput *)captureOutput didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection{
    
    NSLog(@"Buffer");
}









- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}










/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)recordAudio:(id)sender {
    
    if (audioRecorder.isRecording ) {
        [audioRecorder stop];
        [self.recordAudioButton setTitle:@"Record Audio" forState:UIControlStateNormal];
    }else{
        [audioRecorder record];
        [self.recordAudioButton setTitle:@"Stop Record" forState:UIControlStateNormal];
    }
}
- (IBAction)playAudio:(id)sender {
    
    if (audioPlayer.isPlaying) {
        
        
        
        [audioPlayer stop];
        [self.playAudioButton setTitle:@"Play Audio" forState:UIControlStateNormal];
        
    }else{
        if (!audioRecorder.isRecording) {
            audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:audioRecorder.url error:nil];
        }
        [audioPlayer play];
        [self.playAudioButton setTitle:@"Stop Playing" forState:UIControlStateNormal];
    }
    
}
@end
