//
//  ShareKitViewController.h
//  FaceBookIntegration
//
//  Created by Vikas Mishra on 10/21/16.
//  Copyright © 2016 dev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FBSDKShareKit/FBSDKShareKit.h>
@interface ShareKitViewController : UIViewController<FBSDKSharingDelegate>

@end
