//
//  ViewController.h
//  FaceBookIntegration
//
//  Created by Vikas Mishra on 10/20/16.
//  Copyright © 2016 dev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
@interface ViewController : UIViewController<FBSDKLoginButtonDelegate>


@end

